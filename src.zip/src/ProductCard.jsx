import { useState } from 'react'
import { Link } from 'react-router-dom'
import './ProductCard.css'

// Tar bort " tshirt", " mugg", " mug" från produktnamnet för snyggare visning
function formatNamn(namn) {
  return namn
    .replace(/ tshirt$/i, '')
    .replace(/ mugg$/i, '')
    .replace(/ mug$/i, '')
    .trim()
}

function ProductCard({ product, läggTill }) {
  const [tillagd, setTillagd] = useState(false)

  function hanteraKlick(e) {
    e.stopPropagation()
    e.preventDefault()
    läggTill(product)
    setTillagd(true)
    setTimeout(() => setTillagd(false), 1500)
  }

  return (
    <Link to={`/produkt/${product.id}`} className="product-card-link">
      <div className="product-card">
        <div className="product-card-image">
          <img src={product.thumbnail_url || product.image} alt={product.name} />
        </div>
        <div className="product-info">
          <h2>{formatNamn(product.name)}</h2>
          <button
            className={`product-button ${tillagd ? 'tillagd' : ''}`}
            onClick={hanteraKlick}
          >
            {tillagd ? '✓ Tillagd!' : 'Lägg i varukorg'}
          </button>
        </div>
      </div>
    </Link>
  )
}

export default ProductCard
